%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% AstrocteConfig.m: Astrocyte and presynapse config
% author: Eero R�is�nen
% date: 2014 - 2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ***********************************************************************
% If De Pitta simulator for presynapse is turned on the values in matrix a
% are modified during computation and the original values are stored into
% matrix w.
%************************************************************************

% Micrometers to each direction(x,y,z)
% CultureSpace = [180 180 180];
CultureSpace = [750 750 10]; 

% Minimum distance between 2 neurons in micrometers
MinimumNeuronDistance = 10; 

% Minimum distance between 2 astrocytes in micrometers
MinimumAstrocyteDistance = 30; 

% Standard deviation of connection distance
NeuroSTD = 200; 

% Standard deviation of astrocyte connectivity to neuron
ANconnectivitySTD = 150; 

% Absolute maximum distance after which the astrocyte will not connect to synapses
MaxAstrocyteReachDistance = 70;

% If a new (NN and AN) topology is not made an existing topology is loaded
MakeNewTopology = 0;

% If new AN topology is made it is still possible to use an existing neuronal
% network defined here.
if(MakeNewTopology)
    UsePremadeNeuronNetwork = 0;
    PremadeNNTpath = 'C:\Users\lenk\MyData\Publications\19_IEEENanobioscience\Matlab\Networks used\NN-250-30(PaperNN)\';
else
    % Path for the Astrocyte Network.
    TopologyLoadPath = ['C:\Users\lenk\MyData\Publications\19_IEEENanobioscience\Matlab\INEXA20_2D\linkRadius_d_100_c_0.02_y_0.70_run1\'];
    % Path for the Neuron Network.
    PremadeNNTpath = 'C:\Users\lenk\MyData\Publications\19_IEEENanobioscience\Matlab\INEXA20_2D\linkRadius_d_100_c_0.02_y_0.70_run1\';
end

% Is De Pitta presynapse simulator on? boolean
preSynapse = 1;

% Is astrocyte simulator on? boolean
Astrocyte = 1;

% Is astrocyte network simulator on? boolean
AstrocyteNetwork = 1;

% If astrocyte network is on, forcing astrocytes on.
if (AstrocyteNetwork == 1)
    Astrocyte = 1;
end

% If astrocyte simulator is on, forcing presynapse simulator on.
if (Astrocyte == 1)
    preSynapse = 1;
end

if (AstrocyteNetwork == 1)
    SpatialCoordinateSystem = 1;
else
    NumberOfAstrocytes = 0;
    AstrocyteInhibition = 0;
end

if (preSynapse)
    
    % Calcium at terminal bound to sensors at the beginning between 0 and 1.
    Calcium = 0;

    % Resources at each synapse at the beginning between 0 and 1.
    Resources = 1;

	% Glutamate amount at the beginning between 0 and 1. With presynapse
	% simulator only this is a constant. With Astrocyte it becomes
	% variable.
    AstrocyteGlutamate = 0.0;
    
    % Effect parameter of astrocyte regulation of synaptic release
    alpha = 0.7;

    % Regenerate resources. Every ms proportion RegenRes of used resources is
    % added to resources. 0.01 meaning that 1% of used resources is regenerated
    % each cycle. Between 0 and 1.
    RegenRes = 0.02;

    % Regenerate Calcium equilibrium in presynapse. Each ms calcium bound to
    % sensors drops to proportion CaRegen of the previous value. 0.99 meaning
    % that 99% of calcium is left compared to previous amount after 1 ms.
    % Between 0 and 1. 
    CaRegen = 0.998;
    
    % Reblock rate of NMDAR magnesium blockade. Mg left after every cycle.
    % Between 0 and 1.
    ReBlock = 0.0;
    
end

if (Astrocyte)
    
    % Removal of glutamate from astrocyte. Percentage of glutamate left after each ms.
    % Omega_g = -log(GlutamateRemoval^5)/0.005
    GlutamateRemoval = 0.999923;

    % Release amount by astrocyte
    AstrocyteReleaseAmount = 0.3;
    
    % Level of Ca initializing glutamate release
    % CaGlutamateReleaseLevelVector = [0.1;0.02;0.1];
    CaGlutamateReleaseLevel = 0.1;
    
    % Cumulation factor for conversion from levels IP3 to calcium. Between
    % 0 and 1.
    IP3accumulation = 0.05;
    
    % Removal of IP3 from single synapse. Percentage of IP3 left after each ms.
    % Omega_IP3 = -log(IP3degrading^5)/0.005
    IP3degrading = 0.85873;
   
end

if (AstrocyteNetwork)    
    
    NumberOfAstrocytes = 63;
    
    % How strong an effect synapses Ca rise has to astrocyte Ca? Higher
    % number is stonger.
    SynapseCaEffect = 5;
    
    % Maximum distance between 2 astrocyte in micrometers
    connectionDistance = distAstro;%100;
    
    % Spontanous activity - only the astrocytes in unactivated state can activate
    SpontaneousActivation = 0;
    
    % Average activation time of an astrocyte in milliseconds
    ActivationProbability = tinMS/1500; %U_t;
    
    % Average 
    ActivationTime = tinMS/7000; %A_t
    
    % Average 
    RefractoryTime = tinMS/5000; %R_t
    
    % Increase in required flux to activate an astrocyte for each connection it has
    slope = 0.02;
    
    % Minimum IP3 flux needed to activate an astrocyte
    intercept = 0.205;
    
    % strength of astrocytic inhibition(negative number)
    AstrocyteInhibitionStrength = -0.01;
  
   
end
