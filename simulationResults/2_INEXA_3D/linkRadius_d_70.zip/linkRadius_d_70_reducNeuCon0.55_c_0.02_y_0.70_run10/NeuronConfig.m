%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NeuronConfig.m: Configuration file of the INEX part
% author: Kerstin Lenk
% date: 2013 - 2018
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Directory for the resulting spike trains
% directory = 'C:\Users\lenk\MyData\Publications\19_IEEENanobioscience\Matlab\INEXA20\linkRadius_d_120_c_0.02_y_0.26';

% Length of the spike train in [msec]
lengthST = 300000;

% time interval in [sec] including refractory time
t = 0.005;         

% Number of excitatory neurons
ex0 = 200; 

% Number of inhibitory neurons
in0 = 50;

% Lower and upper boundary of random number for basic activity
c_k = [0.02;0.0;0.02]; 

% Maximal synaptic strength
maxSynStr = 0.7;
% maxSynStrIN = 0.6;

% Lower and upper boundary of random number for synaptic strength (all positive numbers)
synStr_oex0 = [maxSynStr;0.0;maxSynStr]; % excitatory, to other neurons, group 0
synStr_oin0 = [maxSynStr;0.0;maxSynStr]; % inhibitory, to other neurons, group 0

% synStr_oex0 = [maxSynStr;0.0;maxSynStr]; % excitatory, to other neurons, group 0
% synStr_oin0 = [maxSynStrIN;0.0;maxSynStrIN]; % inhibitory, to other neurons, group 0

% 
sensitivityMultiplier = 0.1;






